# T2G - WTHR 5 Days forecast
A pure javascript script, with some features such as :
* geoip to coordinates
* coordinates to weather forecasts
* city-country to coordinates
etc..

## Features 
* Open-Source
* Json results
* async

# demo and source-code 
* the demo is hosted [on-this-link]
* the source code is [here]

# license
Do what you do the best with it. 
Sincerely , Thibaut LOMBARD.

[comment]: #
   [on-this-link]: <https://api.tel2geo.fr/wthr/demo.html>
   [here]: <http://git.ctrlfagency.com/ctrlfagency/t2g/tree/master/api/wthr/>
