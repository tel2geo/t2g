exports.render = function(req, res) {
    res.render('index', {
    	title: 'VOCALR - GNU Vocal Recognition app by Thibaut LOMBARD'
    });
};
