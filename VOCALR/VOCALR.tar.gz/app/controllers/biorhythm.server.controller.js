exports.render = function(req, res) {
    res.render('biorhythm', {
    	title: 'VOCALR - Biorhythm - vocal recognition - Thibaut LOMBARD'
    });
};
