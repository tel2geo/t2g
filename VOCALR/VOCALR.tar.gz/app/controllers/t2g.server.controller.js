exports.render = function(req, res) {
    res.render('t2g', {
    	title: 'VOCALR - Tel2geo - vocal recognition - Thibaut LOMBARD'
    });
};

