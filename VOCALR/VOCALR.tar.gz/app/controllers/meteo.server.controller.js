exports.render = function(req, res) {
    res.render('meteo', {
    	title: 'VOCALR - Weather - vocal recognition - Thibaut LOMBARD'
    });
};
